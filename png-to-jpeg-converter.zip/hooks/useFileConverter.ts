
import { useState, useCallback } from 'react';
import { UploadedFile, ConversionStatus } from '../types';
import { convertPngToJpegClientSide } from '../utils/fileUtils';
import { DEFAULT_JPEG_QUALITY } from '../constants';

export const useFileConverter = () => {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [globalQuality, setGlobalQuality] = useState<number>(DEFAULT_JPEG_QUALITY);

  const updateFileState = useCallback((fileId: string, updates: Partial<UploadedFile>) => {
    setFiles(prevFiles =>
      prevFiles.map(f => (f.id === fileId ? { ...f, ...updates } : f))
    );
  }, []);

  const addFiles = useCallback((newFiles: File[]) => {
    const processedFiles: UploadedFile[] = newFiles.map(file => ({
      id: `${file.name}-${file.lastModified}-${Math.random().toString(36).substr(2, 9)}`,
      originalFile: file,
      name: file.name,
      size: file.size,
      type: file.type,
      status: ConversionStatus.IDLE,
      progress: 0,
      quality: globalQuality, // Initialize with global quality
    }));
    setFiles(prevFiles => [...prevFiles, ...processedFiles]);
  }, [globalQuality]);

  const removeFile = useCallback((fileId: string) => {
    setFiles(prevFiles => prevFiles.filter(f => f.id !== fileId));
  }, []);

  const clearAllFiles = useCallback(() => {
    setFiles([]);
  }, []);

  const updateFileQuality = useCallback((fileId: string, quality: number) => {
    updateFileState(fileId, { quality });
  }, [updateFileState]);
  
  // Apply global quality to all idle/waiting files
  const handleGlobalQualityChange = useCallback((quality: number) => {
      setGlobalQuality(quality);
      setFiles(prevFiles => 
          prevFiles.map(f => 
              (f.status === ConversionStatus.IDLE || f.status === ConversionStatus.WAITING) 
              ? { ...f, quality: quality } 
              : f
          )
      );
  }, []);


  const startConversion = useCallback(async (fileId: string) => {
    const fileToConvert = files.find(f => f.id === fileId);
    if (!fileToConvert || fileToConvert.status === ConversionStatus.CONVERTING || fileToConvert.status === ConversionStatus.CONVERTED) {
      return;
    }

    updateFileState(fileId, { status: ConversionStatus.CONVERTING, progress: 0, errorMessage: undefined });

    // Simulate progress for better UX, actual conversion might be quick or slow
    let currentProgress = 0;
    const progressInterval = setInterval(() => {
      currentProgress += 10;
      if (currentProgress < 90) { // Don't let simulated progress reach 100% before actual conversion
        updateFileState(fileId, { progress: currentProgress });
      } else {
        clearInterval(progressInterval); // Stop simulation if it gets too high before conversion finishes
      }
    }, 100);


    try {
      const { dataUrl, fileName } = await convertPngToJpegClientSide(fileToConvert.originalFile, fileToConvert.quality);
      clearInterval(progressInterval); // Clear interval once conversion is done
      updateFileState(fileId, {
        status: ConversionStatus.CONVERTED,
        progress: 100,
        convertedDataUrl: dataUrl,
        convertedFileName: fileName,
      });
    } catch (error) {
      clearInterval(progressInterval); // Clear interval on error
      console.error('Conversion error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown conversion error';
      updateFileState(fileId, { status: ConversionStatus.ERROR, progress: 0, errorMessage });
    }
  }, [files, updateFileState]);

  const startAllConversions = useCallback(async () => {
    // Apply global quality to all files that are not yet converted or converting
    setFiles(prevFiles => prevFiles.map(f => {
        if (f.status === ConversionStatus.IDLE || f.status === ConversionStatus.WAITING || f.status === ConversionStatus.ERROR) {
            return { ...f, quality: globalQuality };
        }
        return f;
    }));

    // Give React a moment to update state before starting conversions
    setTimeout(() => {
        const filesToConvert = files.filter(f => f.status === ConversionStatus.IDLE || f.status === ConversionStatus.WAITING || f.status === ConversionStatus.ERROR);
        for (const file of filesToConvert) {
          // Don't await here to run them "concurrently" (browser handles actual concurrency)
          startConversion(file.id);
        }
    }, 50);

  }, [files, startConversion, globalQuality]);

  return {
    files,
    addFiles,
    removeFile,
    clearAllFiles,
    startConversion,
    startAllConversions,
    updateFileQuality,
    globalQuality,
    setGlobalQuality: handleGlobalQualityChange,
  };
};
