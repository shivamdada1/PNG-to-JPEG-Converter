
import React, { useState, useCallback } from 'react';
import { FileUploader } from './components/FileUploader';
import { FileList } from './components/FileList';
import { ConversionOptionsPanel } from './components/ConversionOptionsPanel';
import { FaqSection } from './components/FaqSection';
import { Modal } from './components/Modal';
import { useFileConverter } from './hooks/useFileConverter';
import { APP_TITLE, FAQ_CONTENT, PRIVACY_POLICY_CONTENT, TERMS_OF_SERVICE_CONTENT, BRAND_COLOR_PRIMARY_BG, BRAND_COLOR_PRIMARY_TEXT } from './constants';
import { InfoIcon, ShieldCheckIcon, XMarkIcon } from './components/icons'; // Corrected import path

const App: React.FC = () => {
  const {
    files,
    addFiles,
    removeFile,
    clearAllFiles,
    startConversion,
    startAllConversions,
    updateFileQuality,
    globalQuality,
    setGlobalQuality,
  } = useFileConverter();

  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false);
  const [showBanner, setShowBanner] = useState(true);

  const handleFilesSelected = useCallback((selectedFiles: File[]) => {
    const pngFiles = Array.from(selectedFiles).filter(file => file.type === 'image/png');
    if (pngFiles.length !== selectedFiles.length) {
      alert('Only PNG files are accepted. Non-PNG files have been filtered out.');
    }
    if (pngFiles.length > 0) {
      addFiles(pngFiles);
    }
  }, [addFiles]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100 flex flex-col items-center p-4 selection:bg-sky-400 selection:text-sky-900">
      {showBanner && (
         <div className="fixed top-0 left-0 right-0 bg-sky-600 text-white p-3 text-center text-sm z-50 flex justify-between items-center">
           <span>
             <InfoIcon className="inline-block w-5 h-5 mr-2"/>
             This is a demo application. Your files are processed locally in your browser and are not uploaded to any server.
           </span>
           <button onClick={() => setShowBanner(false)} className="ml-4 p-1 hover:bg-sky-700 rounded-full">
             <XMarkIcon className="w-5 h-5"/>
           </button>
         </div>
      )}

      <header className={`w-full max-w-5xl mx-auto text-center py-8 ${showBanner ? 'mt-12' : ''}`}>
        <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300 mb-3">{APP_TITLE}</h1>
        <p className="text-slate-300 text-lg">Convert PNG to JPEG in seconds! No installation needed—just upload, convert, and download.</p>
        <p className="text-sm text-slate-400 mt-1">Free, secure, and works on any device.</p>
      </header>

      <main className="w-full max-w-4xl mx-auto bg-slate-800 shadow-2xl rounded-lg p-6 md:p-8 space-y-8 ">
        <FileUploader onFilesSelected={handleFilesSelected} />
        
        {files.length > 0 && (
          <>
            <ConversionOptionsPanel
              quality={globalQuality}
              onQualityChange={setGlobalQuality}
              onConvertAll={startAllConversions}
              onClearAll={clearAllFiles}
              hasFiles={files.length > 0}
              isConverting={files.some(f => f.status === 'converting')}
            />
            <FileList files={files} onRemoveFile={removeFile} onConvertFile={startConversion} onUpdateFileQuality={updateFileQuality} />
          </>
        )}
      </main>

      <FaqSection faqItems={FAQ_CONTENT} />

      <footer className="w-full max-w-5xl mx-auto text-center py-8 mt-8 text-slate-400 text-sm">
        <div className="flex justify-center space-x-4 mb-2">
          <button onClick={() => setIsPrivacyModalOpen(true)} className="hover:text-sky-400 transition-colors">Privacy Policy</button>
          <button onClick={() => setIsTermsModalOpen(true)} className="hover:text-sky-400 transition-colors">Terms of Service</button>
        </div>
        <p>&copy; {new Date().getFullYear()} {APP_TITLE}. All rights reserved.</p>
        <p className="mt-2 flex items-center justify-center">
          <ShieldCheckIcon className="w-5 h-5 mr-2 text-green-400" />
          Your files are processed locally and never leave your browser.
        </p>
      </footer>

      <Modal isOpen={isPrivacyModalOpen} onClose={() => setIsPrivacyModalOpen(false)} title="Privacy Policy">
        <div className="prose prose-sm prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: PRIVACY_POLICY_CONTENT }} />
      </Modal>
      <Modal isOpen={isTermsModalOpen} onClose={() => setIsTermsModalOpen(false)} title="Terms of Service">
         <div className="prose prose-sm prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: TERMS_OF_SERVICE_CONTENT }} />
      </Modal>
    </div>
  );
};

export default App;
