
import { FaqItem } from './types';

export const APP_TITLE = "PNG to JPEG Converter";
export const BRAND_COLOR_PRIMARY = "#38bdf8"; // sky-400
export const BRAND_COLOR_SECONDARY = "#0ea5e9"; // sky-500
export const BRAND_COLOR_PRIMARY_BG = "bg-sky-600";
export const BRAND_COLOR_PRIMARY_TEXT = "text-sky-400";

export const DEFAULT_JPEG_QUALITY = 85;

export const FAQ_CONTENT: FaqItem[] = [
  {
    question: "How does this PNG to JPEG converter work?",
    answer: "This tool converts your PNG images to JPEG format directly in your browser. Simply upload your PNG files, adjust quality if needed, and click convert. Your files are not uploaded to any server, ensuring privacy and speed."
  },
  {
    question: "Is this service free to use?",
    answer: "Yes, this online PNG to JPEG converter is completely free to use. There are no hidden charges or limitations on the number of conversions."
  },
  {
    question: "Can I convert multiple files at once?",
    answer: "Absolutely! You can upload multiple PNG files and convert them in a batch. Each file's progress will be shown, and you can download them individually or (in future versions) as a zip."
  },
  {
    question: "What happens to my files after conversion?",
    answer: "Since all processing happens in your browser, your files are never sent to our servers. Once you close the browser tab or clear the file list, the data is gone. We prioritize your privacy and security."
  },
  {
    question: "What is the difference between PNG and JPEG?",
    answer: "PNG (Portable Network Graphics) is a lossless format, ideal for images with transparency or sharp lines like logos and text. JPEG (Joint Photographic Experts Group) is a lossy format, best for photographs where some quality loss is acceptable for smaller file sizes."
  },
  {
    question: "How do I adjust the JPEG quality?",
    answer: "You can use the quality slider (0-100) before starting the conversion. Higher quality means a larger file size, while lower quality results in smaller files but may introduce visual artifacts. The default is usually a good balance."
  }
];

export const PRIVACY_POLICY_CONTENT = `
  <h2 class="text-lg font-semibold mb-2">Privacy Policy</h2>
  <p class="mb-2"><strong>Last updated: ${new Date().toLocaleDateString()}</strong></p>
  <p class="mb-2">This PNG to JPEG Converter ("Service") is committed to protecting your privacy. This Privacy Policy explains how your information is handled when you use our Service.</p>
  <p class="mb-2"><strong>Information We Don't Collect:</strong> We do not collect, store, or transmit any personal information or any of your uploaded image files. All image conversion processes are performed locally within your web browser.</p>
  <p class="mb-2"><strong>Local Processing:</strong> Your files are not uploaded to any external server. They remain on your device throughout the conversion process. Once you close your browser or refresh the page, all data related to your session is cleared.</p>
  <p class="mb-2"><strong>Cookies:</strong> We do not use cookies for tracking or advertising purposes. Any cookies used are strictly for essential site functionality (if any).</p>
  <p class="mb-2"><strong>Third-Party Services:</strong> This Service does not integrate with any third-party services that would collect your data.</p>
  <p class="mb-2"><strong>Changes to This Privacy Policy:</strong> We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>
  <p class="mb-2"><strong>Contact Us:</strong> If you have any questions about this Privacy Policy, please contact us (hypothetically, as this is a demo).</p>
`;

export const TERMS_OF_SERVICE_CONTENT = `
  <h2 class="text-lg font-semibold mb-2">Terms of Service</h2>
  <p class="mb-2"><strong>Last updated: ${new Date().toLocaleDateString()}</strong></p>
  <p class="mb-2">By using this PNG to JPEG Converter ("Service"), you agree to be bound by these Terms of Service.</p>
  <p class="mb-2"><strong>1. Use of Service:</strong> You may use this Service for its intended purpose of converting PNG images to JPEG format. You agree not to use the Service for any illegal or unauthorized purpose.</p>
  <p class="mb-2"><strong>2. No Warranty:</strong> The Service is provided "as is" without any warranties of any kind, express or implied. We do not guarantee that the Service will be error-free or uninterrupted, or that conversions will always be perfect.</p>
  <p class="mb-2"><strong>3. Limitation of Liability:</strong> In no event shall the Service provider be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on the Service's website, even if the Service provider or an authorized representative has been notified orally or in writing of the possibility of such damage.</p>
  <p class="mb-2"><strong>4. Intellectual Property:</strong> You retain all rights to the images you convert. We claim no ownership over your content.</p>
  <p class="mb-2"><strong>5. Modifications to Service:</strong> We reserve the right to modify or discontinue the Service at any time without notice.</p>
  <p class="mb-2"><strong>6. Governing Law:</strong> These terms and conditions are governed by and construed in accordance with the laws of a hypothetical jurisdiction and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.</p>
`;
