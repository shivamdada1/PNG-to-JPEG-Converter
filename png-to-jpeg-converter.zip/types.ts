
export enum ConversionStatus {
  IDLE = 'idle',
  WAITING = 'waiting',
  CONVERTING = 'converting',
  CONVERTED = 'converted',
  ERROR = 'error',
}

export interface UploadedFile {
  id: string;
  originalFile: File;
  name: string;
  size: number;
  type: string;
  status: ConversionStatus;
  progress: number; // 0-100
  quality: number; // 0-100, specific to this file if overridden
  convertedDataUrl?: string;
  convertedFileName?: string;
  errorMessage?: string;
}

export interface ConversionOptions {
  quality: number; // 0-100
  targetFormat: 'jpeg'; // Could be extended later
}

export interface FaqItem {
  question: string;
  answer: string;
}
