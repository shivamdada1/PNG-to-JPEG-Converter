
import React, { useState } from 'react';
import { FaqItem } from '../types';
import { ChevronDownIcon, ChevronUpIcon } from './icons'; // Corrected import path

interface FaqSectionProps {
  faqItems: FaqItem[];
}

const FaqItemDisplay: React.FC<{ item: FaqItem }> = ({ item }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-slate-700">
      <h3>
        <button
          type="button"
          className="flex justify-between items-center w-full py-5 px-1 text-left font-medium text-slate-300 hover:text-sky-400 focus:outline-none"
          onClick={() => setIsOpen(!isOpen)}
          aria-expanded={isOpen}
        >
          <span>{item.question}</span>
          {isOpen ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
        </button>
      </h3>
      {isOpen && (
        <div className="pb-5 px-1">
          <p className="text-slate-400 text-sm">{item.answer}</p>
        </div>
      )}
    </div>
  );
};

export const FaqSection: React.FC<FaqSectionProps> = ({ faqItems }) => {
  return (
    <section className="w-full max-w-3xl mx-auto mt-12 bg-slate-800 shadow-xl rounded-lg p-6 md:p-8">
      <h2 className="text-3xl font-bold text-center text-slate-100 mb-8">Frequently Asked Questions</h2>
      <div className="space-y-1">
        {faqItems.map((item, index) => (
          <FaqItemDisplay key={index} item={item} />
        ))}
      </div>
    </section>
  );
};
