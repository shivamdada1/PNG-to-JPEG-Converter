
import React from 'react';
import { UploadedFile, ConversionStatus } from '../types';
import { formatBytes } from '../utils/fileUtils';
import { ProgressBar } './ProgressBar';
import { CheckCircleIcon, ArrowDownTrayIcon, XCircleIcon, TrashIcon, ArrowPathIcon, CogIcon } from './icons'; // Corrected import path

interface FileItemProps {
  file: UploadedFile;
  onRemove: (fileId: string) => void;
  onConvert: (fileId: string) => void;
  onUpdateQuality: (fileId: string, quality: number) => void;
}

export const FileItem: React.FC<FileItemProps> = ({ file, onRemove, onConvert, onUpdateQuality }) => {
  const handleDownload = () => {
    if (file.convertedDataUrl && file.convertedFileName) {
      const link = document.createElement('a');
      link.href = file.convertedDataUrl;
      link.download = file.convertedFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const renderStatusIndicator = () => {
    switch (file.status) {
      case ConversionStatus.WAITING:
        return <span className="text-xs text-yellow-400 flex items-center"><CogIcon className="w-4 h-4 mr-1 animate-spin-slow"/>Waiting</span>;
      case ConversionStatus.CONVERTING:
        return <span className="text-xs text-blue-400 flex items-center"><ArrowPathIcon className="w-4 h-4 mr-1 animate-spin"/>Converting...</span>;
      case ConversionStatus.CONVERTED:
        return <span className="text-xs text-green-400 flex items-center"><CheckCircleIcon className="w-4 h-4 mr-1"/>Converted</span>;
      case ConversionStatus.ERROR:
        return <span className="text-xs text-red-400 flex items-center" title={file.errorMessage}><XCircleIcon className="w-4 h-4 mr-1"/>Error</span>;
      default: // IDLE
        return <span className="text-xs text-slate-400">Ready</span>;
    }
  };

  return (
    <div className="bg-slate-700 p-4 rounded-lg shadow-md flex flex-col md:flex-row items-start md:items-center justify-between space-y-3 md:space-y-0">
      <div className="flex-grow overflow-hidden pr-4">
        <p className="text-sm font-medium text-slate-100 truncate" title={file.name}>{file.name}</p>
        <p className="text-xs text-slate-400">{formatBytes(file.size)} - {file.type}</p>
        {renderStatusIndicator()}
        {file.status === ConversionStatus.CONVERTING && <ProgressBar progress={file.progress} />}
        {file.status === ConversionStatus.ERROR && file.errorMessage && (
          <p className="text-xs text-red-400 mt-1 truncate" title={file.errorMessage}>Error: {file.errorMessage}</p>
        )}
      </div>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 w-full md:w-auto">
        {file.status !== ConversionStatus.CONVERTED && file.status !== ConversionStatus.CONVERTING && (
          <div className="flex items-center space-x-2">
            <label htmlFor={`quality-${file.id}`} className="text-xs text-slate-300 whitespace-nowrap">Quality:</label>
            {/*锦 Fixed: Removed redundant disabled prop. The input is only rendered when it should be enabled. */}
            <input
              type="range"
              id={`quality-${file.id}`}
              min="1"
              max="100"
              value={file.quality}
              onChange={(e) => onUpdateQuality(file.id, parseInt(e.target.value))}
              className="w-full sm:w-20 h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-500"
            />
            <span className="text-xs text-slate-300 w-8 text-right">{file.quality}%</span>
          </div>
        )}

        {file.status === ConversionStatus.IDLE || file.status === ConversionStatus.WAITING || file.status === ConversionStatus.ERROR ? (
          //锦 Fixed: Removed redundant disabled prop. The button is only rendered when it should be enabled.
          <button
            onClick={() => onConvert(file.id)}
            className="px-3 py-1.5 text-xs bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-md transition-colors flex items-center justify-center whitespace-nowrap"
          >
            <CogIcon className="w-4 h-4 mr-1"/> Convert to JPEG
          </button>
        ) : null}

        {file.status === ConversionStatus.CONVERTED && (
          <button
            onClick={handleDownload}
            className="px-3 py-1.5 text-xs bg-green-500 hover:bg-green-600 text-white font-medium rounded-md transition-colors flex items-center justify-center whitespace-nowrap"
          >
           <ArrowDownTrayIcon className="w-4 h-4 mr-1"/> Download JPEG
          </button>
        )}
        
        <button
          onClick={() => onRemove(file.id)}
          title="Remove file"
          className="px-3 py-1.5 text-xs bg-slate-600 hover:bg-red-500 text-slate-200 hover:text-white font-medium rounded-md transition-colors flex items-center justify-center"
        >
          <TrashIcon className="w-4 h-4"/>
        </button>
      </div>
    </div>
  );
};
