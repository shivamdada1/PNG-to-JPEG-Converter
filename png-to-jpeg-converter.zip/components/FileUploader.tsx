
import React, { useState, useCallback, useRef } from 'react';
import { UploadCloudIcon } from './icons'; // Corrected import path

interface FileUploaderProps {
  onFilesSelected: (files: File[]) => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onFilesSelected }) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    // You can add more sophisticated drag over effects here
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFilesSelected(Array.from(e.dataTransfer.files));
      e.dataTransfer.clearData();
    }
  }, [onFilesSelected]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFilesSelected(Array.from(e.target.files));
      e.target.value = ''; // Reset file input
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div
      className={`w-full p-8 border-4 ${
        isDragging ? 'border-sky-400 bg-slate-700' : 'border-dashed border-slate-600 hover:border-slate-500'
      } rounded-lg text-center cursor-pointer transition-all duration-300 ease-in-out flex flex-col items-center justify-center min-h-[200px]`}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onClick={handleBrowseClick}
    >
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept="image/png"
        multiple
        onChange={handleFileChange}
      />
      <UploadCloudIcon className={`w-16 h-16 mb-4 ${isDragging ? 'text-sky-300' : 'text-slate-500'} transition-colors`} />
      <p className={`text-xl font-semibold ${isDragging ? 'text-sky-300' : 'text-slate-300'} mb-2`}>
        Drag & Drop your PNG files here
      </p>
      <p className="text-slate-400">or</p>
      <button
        type="button"
        className="mt-2 px-6 py-2 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-md shadow-md transition-transform duration-150 ease-in-out hover:scale-105 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75"
      >
        Browse Files
      </button>
      <p className="text-xs text-slate-500 mt-4">Only PNG files are accepted.</p>
    </div>
  );
};
