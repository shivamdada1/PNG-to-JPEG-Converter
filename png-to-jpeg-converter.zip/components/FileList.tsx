
import React from 'react';
import { UploadedFile } from '../types';
import { FileItem } from './FileItem';

interface FileListProps {
  files: UploadedFile[];
  onRemoveFile: (fileId: string) => void;
  onConvertFile: (fileId: string) => void;
  onUpdateFileQuality: (fileId: string, quality: number) => void;
}

export const FileList: React.FC<FileListProps> = ({ files, onRemoveFile, onConvertFile, onUpdateFileQuality }) => {
  if (files.length === 0) {
    return (
      <div className="text-center text-slate-400 py-8">
        <p>No files uploaded yet. Drag and drop PNG files above to get started.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold text-slate-200 mb-4">Uploaded Files</h2>
      {files.map(file => (
        <FileItem
          key={file.id}
          file={file}
          onRemove={onRemoveFile}
          onConvert={onConvertFile}
          onUpdateQuality={onUpdateFileQuality}
        />
      ))}
    </div>
  );
};
