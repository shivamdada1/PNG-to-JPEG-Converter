
import React from 'react';
import { DEFAULT_JPEG_QUALITY } from '../constants';
import { CogIcon, TrashIcon } from './icons'; // Corrected import path

interface ConversionOptionsPanelProps {
  quality: number;
  onQualityChange: (quality: number) => void;
  onConvertAll: () => void;
  onClearAll: () => void;
  hasFiles: boolean;
  isConverting: boolean;
}

export const ConversionOptionsPanel: React.FC<ConversionOptionsPanelProps> = ({
  quality,
  onQualityChange,
  onConvertAll,
  onClearAll,
  hasFiles,
  isConverting
}) => {
  if (!hasFiles) return null;

  return (
    <div className="bg-slate-750 p-4 rounded-lg shadow-md space-y-4 border border-slate-700">
      <h3 className="text-lg font-semibold text-slate-200">Conversion Options</h3>
      <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4">
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <label htmlFor="globalQuality" className="text-sm text-slate-300 whitespace-nowrap">Global JPEG Quality:</label>
          <input
            type="range"
            id="globalQuality"
            min="1"
            max="100"
            value={quality}
            onChange={(e) => onQualityChange(parseInt(e.target.value))}
            className="w-full sm:w-32 h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-500"
            disabled={isConverting}
          />
          <span className="text-sm text-slate-300 w-10 text-right">{quality}%</span>
        </div>
        <button 
          onClick={() => onQualityChange(DEFAULT_JPEG_QUALITY)}
          className="px-3 py-1 text-xs bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md transition-colors whitespace-nowrap"
          disabled={isConverting}
        >
          Reset Quality
        </button>
      </div>
      <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 pt-2">
        <button
          onClick={onConvertAll}
          className="w-full sm:w-auto px-6 py-2.5 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-md shadow-md transition-transform duration-150 ease-in-out hover:scale-105 focus:outline-none focus:ring-2 focus:ring-sky-400 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          disabled={!hasFiles || isConverting}
        >
          <CogIcon className="w-5 h-5 mr-2"/>
          Convert All to JPEG
        </button>
        <button
          onClick={onClearAll}
          className="w-full sm:w-auto px-6 py-2.5 bg-red-500 hover:bg-red-600 text-white font-semibold rounded-md shadow-md transition-transform duration-150 ease-in-out hover:scale-105 focus:outline-none focus:ring-2 focus:ring-red-400 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          disabled={!hasFiles || isConverting}
        >
          <TrashIcon className="w-5 h-5 mr-2"/>
          Clear All Files
        </button>
      </div>
      {isConverting && <p className="text-sm text-sky-400 italic mt-2">Conversion in progress, please wait...</p>}
    </div>
  );
};
