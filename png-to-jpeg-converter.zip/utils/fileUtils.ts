
export const formatBytes = (bytes: number, decimals = 2): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

export const convertPngToJpegClientSide = (
  pngFile: File,
  quality: number // 0-100
): Promise<{ dataUrl: string; fileName: string }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (!event.target || !event.target.result) {
        reject(new Error('Failed to read file.'));
        return;
      }
      
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Failed to get canvas context.'));
          return;
        }
        
        // Fill background with white for PNGs with transparency
        // JPEGs don't support transparency, so transparent areas become black otherwise
        ctx.fillStyle = '#FFFFFF'; 
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.drawImage(img, 0, 0);
        
        try {
          const jpegDataUrl = canvas.toDataURL('image/jpeg', quality / 100);
          const baseName = pngFile.name.substring(0, pngFile.name.lastIndexOf('.')) || pngFile.name;
          const jpegFileName = `${baseName}.jpeg`;
          resolve({ dataUrl: jpegDataUrl, fileName: jpegFileName });
        } catch (e) {
          reject(new Error(`Failed to convert to JPEG: ${e instanceof Error ? e.message : String(e)}`));
        }
      };
      img.onerror = () => {
        reject(new Error('Failed to load image. The file might be corrupted or not a valid PNG.'));
      };
      img.src = event.target.result as string;
    };
    reader.onerror = () => {
      reject(new Error('Error reading file.'));
    };
    reader.readAsDataURL(pngFile);
  });
};
